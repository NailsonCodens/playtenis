interface IFindGameDTO {
  court_id: string;
  date_start_game: Date;
}

export { IFindGameDTO };
