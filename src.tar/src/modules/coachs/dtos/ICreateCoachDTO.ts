interface ICreateCoachDTO {
  id?: string;
  name: string;
  registration: string;
  status: string;
}

export { ICreateCoachDTO };
