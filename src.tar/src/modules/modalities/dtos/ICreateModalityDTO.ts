interface ICreateModalityDTO {
  id?: string;
  name: string;
  amount_players: string;
  time: number;
  status: string;
}

export { ICreateModalityDTO };
