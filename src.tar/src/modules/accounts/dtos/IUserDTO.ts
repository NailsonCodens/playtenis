interface IUserDTO {
  id?: string;
  name: string;
  surname: string;
  login: string;
  password: string;
}

export { IUserDTO };
