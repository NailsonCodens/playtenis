interface ICourtDTO {
  id?: string;
  name: string;
  status?: string;
}

export { ICourtDTO };
