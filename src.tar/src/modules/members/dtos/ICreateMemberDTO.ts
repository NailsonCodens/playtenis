interface ICreateMemberDTO {
  id?: string;
  name: string;
  registration: string;
  status: string;
  type?: string;
}

export { ICreateMemberDTO };
