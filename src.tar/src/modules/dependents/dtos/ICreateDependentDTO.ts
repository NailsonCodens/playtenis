interface ICreateDependentDTO {
  member_id: string;
  player_id: string;
  id?: string;
}

export { ICreateDependentDTO };
