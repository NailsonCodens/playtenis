interface ICreateMemberDependentDTO {
  name: string;
  member_id: string;
  registration: string;
  status: string;
  id?: string;
}

export { ICreateMemberDependentDTO };
